module.exports = {
    "separator": "/",
    "dir": "/Volumes/PROJECTS/git/nodejs/nodejs_practical/Cassite/blogs",
    "suffix": ".md",
    "checking_interval": 600000,
    "default_latest_count": 10,
    "preview_for_out": 5,
    "preview_words": 100
};